import React from 'react'

function Navbar() {
  return (
    <div>This is a nav bar.</div>
  )
}

export default Navbar